#!/usr/bin/env bash
set -euo pipefail

source_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
requested="${1:-.}"

is_project() {
  [[ -f "$1/package.json" ]] && grep -q '"name"[[:space:]]*:[[:space:]]*"classroom-attendance-platform"' "$1/package.json"
}

if is_project "$requested"; then
  target="$(cd "$requested" && pwd)"
elif is_project .; then
  target="$(pwd)"
elif is_project ./classroom-attendance-platform; then
  target="$(cd ./classroom-attendance-platform && pwd)"
else
  echo "Could not find the ClassroomOps project." >&2
  echo "Run this script from the project folder or pass its absolute path." >&2
  exit 1
fi

cp -R "$source_dir/files/." "$target/"
echo "ClassroomOps cumulative update applied to: $target"
echo "You may now delete the extracted classroomops-complete-update folder."
echo "Next: npm install && npm run lint && npm run test -- --run && npm run build"
echo "Then: supabase link --project-ref YOUR_REF && supabase db push"
